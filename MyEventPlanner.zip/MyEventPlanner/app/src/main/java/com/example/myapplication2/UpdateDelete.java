package com.example.myapplication2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.content.Intent;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class UpdateDelete extends DBActivity {
    protected EditText editName, editTel, editEvent, editPlace;
    protected Button btnUpdate, btnDelete;
    protected String ID;

    private void BackToMain(){
        finishActivity(200);
        Intent i=new Intent(UpdateDelete.this, MainActivity.class);
        startActivity(i);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_delete);
        editName=findViewById(R.id.editName);
        editTel=findViewById(R.id.editTel);
        editEvent=findViewById(R.id.editEvent);
        editPlace=findViewById(R.id.editPlace);
        btnUpdate=findViewById(R.id.btnUpdate);
        btnDelete=findViewById(R.id.btnDelete);
        Bundle b=getIntent().getExtras();
        if(b!=null){
            ID=b.getString("ID");
            editName.setText(b.getString("Name"));
            editTel.setText(b.getString("Tel"));
            editEvent.setText(b.getString("Event"));
            editPlace.setText(b.getString("Place"));
        }
        btnDelete.setOnClickListener(view -> {
            try{
                ExecSQL("DELETE FROM NEWEVENTT WHERE " +
                                "ID = ?",
                        new Object[]{ID},
                        ()-> Toast.makeText(getApplicationContext(),
                                "Delete Successful", Toast.LENGTH_LONG).show()
                );

            }catch (Exception exception){
                Toast.makeText(getApplicationContext(),
                        "Delete Error: "+exception.getLocalizedMessage(),
                        Toast.LENGTH_LONG).show();
            }finally {
                BackToMain();
            }
        });

        btnUpdate.setOnClickListener(view -> {
            try{

                ExecSQL("UPDATE NEWEVENTT SET " +
                                "Name = ?, " +
                                "Tel = ?, " +
                                "Event = ?, " +
                                "Place = ? " +
                                "WHERE ID = ?",
                        new Object[]{
                                editName.getText().toString(),
                                editTel.getText().toString(),
                                editEvent.getText().toString(),
                                editPlace.getText().toString(),
                                ID},
                        ()-> Toast.makeText(getApplicationContext(),
                                "Update Successful", Toast.LENGTH_LONG).show()
                );

            }catch (Exception exception){
                Toast.makeText(getApplicationContext(),
                        "Update Error: "+exception.getLocalizedMessage(),
                        Toast.LENGTH_LONG).show();
            }finally {
                BackToMain();
            }
        });


    }
}